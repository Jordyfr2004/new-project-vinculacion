export class AdministradorEntity {}
