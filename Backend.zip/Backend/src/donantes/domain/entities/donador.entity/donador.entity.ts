export class DonadorEntity {}
