export class DonacionEntity {}
