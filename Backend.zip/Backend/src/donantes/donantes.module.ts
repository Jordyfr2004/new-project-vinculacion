import { Module } from '@nestjs/common';
import { DonantesController } from './controllers/donador/donantes.controller';
import {  DonadorService} from './services/donador/donador.service';
import { DonacionService } from './services/donacion/donacion.service';
import { DonacionController } from './controllers/donacion/donacion.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DonacionModel } from './domain/models/donacion.model/donacion.model';
import { Donador } from './domain/models/donador/donador';
import { DonacionRepository } from './infrastructure/repositories/donacion.repository/donacion.repository';
import { DonadorRepository } from './infrastructure/repositories/donador.repository/donador.repository';

@Module({
  imports:[TypeOrmModule.forFeature([
    DonacionModel,Donador

  ])],
  controllers: [DonantesController, DonacionController],
  providers: [DonadorService, DonacionService, DonacionRepository,DonadorRepository],
  exports:[ DonadorService,DonacionService]
})
export class DonantesModule {}
