export class ReceptorEntity {}
