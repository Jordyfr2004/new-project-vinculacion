export class SolicitudEntity {}
